/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

define(['AnchorsPanePanel'
            , 'BorderPanePanel'
            , 'CardPanePanel'
            , 'DesktopPanePanel'
            , 'FlowPanePanel'
            , 'GridPanePanel'
            , 'HBoxPanePanel'
            , 'SplitPanePanel'
            , 'TabbedPanePanel'
            , 'ToolbarPanel'
            , 'VBoxPanePanel'
            , 'AddComponentContainer']
        , function (AnchorsPanePanel, BorderPanePanel, CardPanePanel, DesktopPanePanel
                , FlowPanePanel, GridPanePanel, HBoxPanePanel, SplitPanePanel
                , TabbedPanePanel, ToolbarPanel, VBoxPanePanel, AddComponentContainer, ModuleName) {
        });
