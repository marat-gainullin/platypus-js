/**
 *
 * @author user
 * @name qAllVisits
 * @public
 */ 
Select * 
From VISIT t1