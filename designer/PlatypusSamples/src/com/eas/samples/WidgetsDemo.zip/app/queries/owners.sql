/**
 *
 * @author user
 * @name owners
 * @public
 */ 
Select t1.owners_id, t1.lastname as name
From OWNERS t1