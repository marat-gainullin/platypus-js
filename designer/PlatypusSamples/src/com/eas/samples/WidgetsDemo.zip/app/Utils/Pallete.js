/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


define(function () {
    return [
        '#e74c3c', '#26a65b', '#2980b9', '#27ae60', '#c0392b', '#7f8c8d'
                , '#8e44ad', '#1dd2af', '#19b698', '#40d47e', '#2cc36b', '#4aa3df'
                , '#2e8ece', '#a66bbe', '#9b50ba', '#3d566e', '#354b60', '#f2ca27'
                , '#e98b39', '#f4a62a', '#ec5e00', '#ea6153', '#d14233', '#cbd0d3'
                , '#a3b1b2', '#8c9899', '#1abc9c', '#16a085', '#2ecc71', '#27ae60'
                , '#3498db', '#2980b9', '#9b59b6', '#8e44ad', '#34495e', '#2c3e50'
                , '#f1c40f', '#f39c12', '#e67e22', '#d35400', '#e74c3c', '#c0392b'
                , '#95a5a6'
    ];
});