/**
 *
 * @author user
 * @name qAllOwners
 * @public
 */ 
Select * 
From OWNERS t1