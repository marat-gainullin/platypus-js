/**
 *
 * @author user
 * @name pets
 * @public
 */ 
Select t1.pets_id, t1.owner_id, t1.name 
From PETS t1