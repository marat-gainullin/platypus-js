/**
 *
 * @author user
 * @name qPetTypes
 * @public
 */ 
Select * 
From PETTYPES t1