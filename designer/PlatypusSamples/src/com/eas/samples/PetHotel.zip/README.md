pethotel
========

Sample PetHotel application on PlatypusPlatform
Use database schema in folder db with username test and same password
