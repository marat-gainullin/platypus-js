/**
 * @public
 * @name OwnerQuery
 */ 
Select * 
From OWNERS t1
 Where :ownerID = t1.OWNERS_ID