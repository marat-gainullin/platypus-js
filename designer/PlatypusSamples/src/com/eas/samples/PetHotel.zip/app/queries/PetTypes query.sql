/**
 * Gets all types for pets.
 * @public 
 * @author vv
 * @name PetTypesQuery
 */ 
Select * 
From PETTYPES t1